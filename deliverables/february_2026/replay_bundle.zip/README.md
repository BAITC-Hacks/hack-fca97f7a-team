# Февральский прогноз: переносимый пакет

Содержит 56 расчётов для T1/T2 (48 часов каждый), сохранённые погодные выпуски Open-Meteo, входные CSV и две использованные модели. Доступность каждого выпуска в прошлом **предполагается** по консервативному правилу; исторический журнал публикации отсутствует. Февральской фактической мощности нет, поэтому точность не рассчитана.

Погодные данные: Open-Meteo Single Runs, модель ECMWF IFS. Документация источника: https://open-meteo.com/en/docs/single-runs-api . Условия Open-Meteo: https://open-meteo.com/en/terms . Данные предоставлены по CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Источник исходной модели: https://www.ecmwf.int/en/forecasts/datasets/open-data .

Для повторного расчёта используйте доверенную копию кода проекта и совместимые версии Python/scikit-learn из bundle_manifest.json. Загружайте pickle только из доверенного пакета.

```sh
ARTIFACT_DIR=<bundle>/artifacts REPLAY_WEATHER_DIR=<bundle>/artifacts/replay_weather python -m scripts.replay --weather-source provider-documented --output-dir <bundle>/reproduced
```

Сравните reproduced/documented_forecast.csv с artifacts/february_replay/documented_forecast.csv и reproduced/documented_daily_forecast.csv с соответствующим файлом пакета.
